

ESX               = nil


--[[
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
--print('^5DGSNL^1 gs_CarLock^7 Is Geladen...^1 v1.03 ^7(Script By DJS)')
ESX.RegisterServerCallback('CarLock:isVehicleOwner', function(source, cb, plate)
	local identifier = GetPlayerIdentifier(source, 0)

	MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE owner = @owner AND plate = @plate', {
		['@owner'] = identifier,
		['@plate'] = plate
	}, function(result)
		if result[1] then
			cb(result[1].owner == identifier)
		else
			cb(true)
		end
	end)
end)
]]

--[[
-- Codigo sacado de ambulancejob/server/main.lua

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
ESX.RegisterServerCallback('CarLock:isVehicleOwner', function(source, cb, nearbyVehicles)
	local xPlayer = ESX.GetPlayerFromId(source)
	local foundPlate, foundNum

	for k,v in ipairs(nearbyVehicles) do
		local result = MySQL.Sync.fetchAll('SELECT plate FROM owned_vehicles WHERE owner = @owner AND plate = @plate', {
			['@owner'] = xPlayer.identifier,
			['@plate'] = v.plate
		})

		if result[1] then
			foundPlate, foundNum = result[1].plate, k
			break
		end
	end

	if not foundPlate then
		cb(false)
		end
	end)
]]

ESX = nil

while ESX == nil do
	TriggerEvent('esx:getSharedObject', function(obj) 
		ESX = obj
	end)
end

--print('^5JalalLinuX ^7: ^1'..GetCurrentResourceName()..'^7 started ^2successfully^7... (^3https://jalallinux.ir)^7')
-- Se borro el owner en la consulta y se deja todo a plate
ESX.RegisterServerCallback('CarLock:isVehicleOwner', function(source, cb, plate)
	local identifier = GetPlayerIdentifier(source, 0)

	MySQL.Async.fetchAll('SELECT plate FROM owned_vehicles WHERE plate = @plate', {
		--['@owner'] = identifier,
		['@plate'] = plate
	}, function(result)
		if result[1] then
			cb(result[1].plate == plate)
		else
			cb(false)
		end
	end)
end)
